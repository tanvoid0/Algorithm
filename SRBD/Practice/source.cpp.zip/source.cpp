#include <stdio.h>
#define maxc 10000000000000
#define minc 100000
int T, Case, ans;
long long int a, b, c, x, n;
void readcase() {
	scanf("%lld %lld %lld %lld", &a, &b, &c, &x);
}

long long int solve(long long int low, long long int high) {
	if (low <= high) {
		mid = (low + high) / 2;
	}
}

void solvecase() {
	long long int low, high;
	if (c == 0)
	{
		low = 0;
		high = maxc;
		ans = solve(0, maxc);
	}
	else {
		low = 0;
		high = minc;
		ans = solve(0, minc);
	}
}
int main() {
	scanf("%d", &T);
	for (Case = 1; Case <= T; Case++) {
		readcase();
		solvecase();
		printcase();
	}
}