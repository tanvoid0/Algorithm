#include<stdio.h>
int n,life,ans;
int m=5;
int cnt=0;
int mat[100][10];
void solve(int x,int y,int cnt,int life)
{
    if(x<0)
    {
        if(cnt>ans)
        {
            ans=cnt;
        }
        return ;
    }
    if(life>0&&life<6)
        life--;
    if(mat[x][y]==2)
    {
        if(life==6)
        {
            life--;
        }
        else if(life==0)
        {
            if(ans<cnt)
                ans=cnt;
            return;
        }

    }
    if(mat[x][y]==1)
        cnt++;
         solve(x-1,y,cnt,life);
        if(y-1>=0)
            solve(x-1,y-1,cnt,life);
        if(y+1<5)
            solve(x-1,y+1,cnt,life);


}
void print()
{
    printf("%d\n",ans);
}
void solvecase()
{
    solve(n,2,ans,life);
}
void input()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<5;j++)
        {
            scanf("%d",&mat[i][j]);
        }
    }
    life=6;
    ans=0;
    mat[n][2]=0;
}
int main()
{freopen("out.txt","w",stdout);
    int t;
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
        input();
        solvecase();
        print();
    }

}
