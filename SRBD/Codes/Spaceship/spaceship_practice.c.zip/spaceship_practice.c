#include <stdio.h>
int T, Case, max, N;
int board[101][5];

void readcase()
{
    int i, j;
    scanf("%d", &N);
    for (i = 0; i < N; i++)
        for (j = 0; j < 5; j++)
            scanf("%d", &board[i][j]);
}

void solve(int row, int col, int life, int score)
{
    if (row < 0)
    {
        if (score > max)
            max = score;
        return;
    }
    if (life > 0 && life < 6)
        life--;
    if (1 == board[row][col])
        score++;
    else if (2 == board[row][col])
    {
        if (0 == life)
        {
            if (score > max)
                max = score;
            return;
        }
        else if (6 == life)
            life--;
    }
    if (col - 1 >= 0)
        solve(row - 1, col - 1, life, score);
    solve(row - 1, col, life, score);
    if (col + 1 < 5)
        solve(row - 1, col + 1, life, score);
}

void solvecase()
{
    max = 0;
    board[N][2] = 0;
    solve(N, 2, 6, 0);
}

void printcase()
{
    printf("#%d %d\n", Case, max);
}

int main()
{
    freopen("spaceship_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}