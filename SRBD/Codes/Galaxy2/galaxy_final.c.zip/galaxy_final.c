#include <stdio.h>
#define MAX 1001
#define inf (MAX * MAX)
int T, Case, min;
int x1[5], y1[5], x2[5], y2[5], dist[5], vis[5];
int sx, sy, dx, dy, N;
int Abs(int a, int b)
{
    return a > b ? a - b : b - a;
}

int Dist(int x1, int x2, int y1, int y2)
{
    return Abs(x1, x2) + Abs(y1, y2);
}

void readcase()
{
    int i;
    scanf("%d %d %d %d", &sx, &sy, &dx, &dy);
    scanf("%d", &N);
    for (i = 0; i < N; i++)
    {
        scanf("%d %d %d %d %d", &x1[i], &y1[i], &x2[i], &y2[i], &dist[i]);
        vis[i] = 0;
    }
}

void solve(int x, int y, int cost)
{
    int i, left, right;
    if (cost >= min)
        return;
    int total = Dist(x, dx, y, dy) + cost;
    if (total < min)
        min = total;
    for (i = 0; i < N; i++)
        if (0 == vis[i])
        {
            vis[i] = 1;
            left = Dist(x, x1[i], y, y1[i]);
            right = Dist(x, x2[i], y, y2[i]);
            if (left < right)
                solve(x2[i], y2[i], cost + left + dist[i]);
            else
                solve(x1[i], y1[i], cost + right + dist[i]);
            vis[i] = 0;
        }
}

void solvecase()
{
    min = inf;
    solve(sx, sy, 0);
}

void printcase()
{
    printf("#%d %d\n", Case, min);
}

int main()
{
    freopen("galaxy_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}