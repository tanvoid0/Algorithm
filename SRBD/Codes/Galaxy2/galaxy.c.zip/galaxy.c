#include <stdio.h>
int caseCount;
int x1[5], y1[5], x2[5], y2[5], dis[5];
int sx, sy, dx, dy, N, max;
int used[5];
int Abs(int x, int y)
{
  if (x > y)
    return x - y;
  return y - x;
}
void readCase()
{
  scanf("%d %d %d %d", &sx, &sy, &dx, &dy);
  int i;
  scanf("%d", &N);
  for (i = 0; i < N; i++)
  {
    scanf("%d %d %d %d %d", &x1[i], &y1[i], &x2[i], &y2[i], &dis[i]);
  }
}
void solve(int x, int y, int cost)
{
  int i, left, right;
  if (cost >= max)
    return;
  int total = Abs(x, dx) + Abs(y, dy) + cost;
  if (total < max)
  { //if  taking warmhole is costly, ignoring
    max = total;
  }
  for (i = 0; i < N; i++)
  {
    if (0 == used[i])
    {
      left = Abs(x, x1[i]) + Abs(y, y1[i]);
      right = Abs(x, x2[i]) + Abs(y, y2[i]);
      used[i] = 1;
      if (left < right)
      {
        solve(x2[i], y2[i], cost + left + dis[i]);
      }
      else
      {
        solve(x1[i], y1[i], cost + right + dis[i]);
      }
      used[i] = 0;
    }
  }
}
void solveCase()
{
  int i;
  for (i = 0; i < N; i++)
  {
    used[i] = 0;
  }
  max = 10001 * 10001;
  solve(sx, sy, 0);
}
void printCase()
{
  printf("#%d %d\n", caseCount, max);
}
int main()
{
  int T;
  freopen("galaxy_input.txt", "r", stdin);
  scanf("%d", &T);
  for (caseCount = 1; caseCount <= T; caseCount++)
  {
    readCase();
    solveCase();
    printCase();
  }
  return 0;
}

///input
/*
3
1 0 4 1
4
5 5 9 1 3
7 0 4 7 5
3 1 0 2 3
7 4 4 6 5

18 16 13 5
4
4 3 19 5 5
13 3 18 3 7
16 11 6 15 1
0 15 8 13 5

4 9 2 10
4
4 24 1 22 11
28 23 24 0 15
17 12 2 17 4
16 4 29 2 12
*/
//output #1 4
//#2 16
//#3 3