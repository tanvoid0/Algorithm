#include <stdio.h>
#define TOTAL 30
int T, Case, Ans;
int g1, g2, g3, f1, f2, f3;

int Abs(int a, int b)
{
    return a > b ? a - b : b - a;
}

int Max(int a, int b)
{
    return a > b ? a : b;
}

int Min(int a, int b)
{
    return a < b ? a : b;
}

void readcase()
{
    scanf("%d %d %d %d %d %d", &g1, &f1, &g2, &f2, &g3, &f3);
}

void solvecase()
{
    int i, j, k;
    int left, right;
    int dist1, dist2, dist3, max;
    Ans = TOTAL;
    for (i = 1; i + f1 + f2 + f3 - 1 <= TOTAL; i++)
    {
        left = Abs(i, g1);
        right = Abs(g1, i + f1 - 1);
        dist1 = Max(left, right);
        for (j = i + f1; j + f2 + f3 - 1 <= TOTAL; j++)
        {
            left = Abs(j, g2);
            right = Abs(g2, j + f2 - 1);
            dist2 = Max(left, right);
            for (k = j + f2; k + f3 - 1 <= TOTAL; k++)
            {
                left = Abs(k, g3);
                right = Abs(g3, k + f3 - 1);
                dist3 = Max(left, right);
                max = Max(dist1, dist2);
                max = Max(max, dist3);

                Ans = Min(max, Ans);
            }
        }
    }
}

void printcase()
{
    printf("#%d %d\n", Case, Ans);
}

int main()
{
    freopen("river_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}