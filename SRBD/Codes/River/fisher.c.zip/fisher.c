#include <stdio.h>

int g1, g2, g3, m1, m2, m3;
int T, Case;
int Ans;

void readCase()
{
	scanf("%d%d", &g1, &m1);
	scanf("%d%d", &g2, &m2);
	scanf("%d%d", &g3, &m3);

	//sorting the gate
	if (g1 > g2)
	{
		int temp1 = g1;
		int temp2 = m1;
		g1 = g2;
		m1 = m2;
		g2 = temp1;
		m2 = temp2;
	}
	if (g2 > g3)
	{
		int temp1 = g2;
		int temp2 = m2;
		g2 = g3;
		m2 = m3;
		g3 = temp1;
		m3 = temp2;
	}
	if (g1 > g2)
	{
		int temp1 = g1;
		int temp2 = m1;
		g1 = g2;
		m1 = m2;
		g2 = temp1;
		m2 = temp2;
	}
	//printf("%d %d %d\n", g1, g2, g3);
	//printf("%d %d %d\n", m1, m2, m3);
}
void solveCase()
{
	int i, j, k, q;
	int d1, d2, d3;
	Ans = 999999;
	for (i = 1; i + m1 + m2 + m3 - 1 <= 10; i++)
	{
		d1 = 0;
		for (q = i; q <= i + m1 - 1; q++)
		{
			d1 += (q > g1) ? q - g1 + 1 : g1 - q + 1;
		}
		for (j = i + m1; j + m2 + m3 - 1 <= 10; j++)
		{
			d2 = 0;
			for (q = j; q <= j + m2 - 1; q++)
			{
				d2 += (q > g2) ? q - g2 + 1 : g2 - q + 1;
			}
			for (k = j + m2; k + m3 - 1 <= 10; k++)
			{
				d3 = 0;
				for (q = k; q <= k + m3 - 1; q++)
				{
					d3 += (q > g3) ? q - g3 + 1 : g3 - q + 1;
				}
				if (d1 + d2 + d3 < Ans)
				{
					Ans = d1 + d2 + d3;
				}
			}
		}
	}
}
void printCase()
{
	printf("#%d %d\n", Case, Ans);
}

int main()
{
	freopen("river_input.txt", "r", stdin);
	scanf("%d", &T);
	for (Case = 1; Case <= T; Case++)
	{
		readCase();
		solveCase();
		printCase();
	}
	return 0;
}