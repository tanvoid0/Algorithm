#include <stdio.h>
#define TOTAL 30
int T, Case, Ans;
int gate1, gate2, gate3, fishermen1, fishermen2, fishermen3;

int Abs(int a, int b)
{
    return a > b ? a - b : b - a;
}

void readcase()
{
    scanf("%d %d %d %d %d %d", &gate1, &fishermen1, &gate2, &fishermen2, &gate3, &fishermen3);
}

void solvecase()
{
    int i, j, k;
    int left, right;
    int dist1, dist2, dist3, max;
    Ans = TOTAL;
    for (i = 1; i + fishermen1 + fishermen2 + fishermen3 - 1 <= TOTAL; i++)
    {
        left = Abs(gate1, i);
        right = Abs(i + fishermen1 - 1, gate1);
        if (left > right)
            dist1 = left;
        else
            dist1 = right;
        for (j = i + fishermen1; j + fishermen2 + fishermen3 - 1 <= TOTAL; j++)
        {
            left = Abs(gate2, j);
            right = Abs(gate2, j + fishermen2 - 1);
            if (left > right)
                dist2 = left;
            else
                dist2 = right;
            for (k = j + fishermen2; k + fishermen3 - 1 <= TOTAL; k++)
            {
                left = Abs(gate3, k);
                right = Abs(gate3, k + fishermen3 - 1);
                if (left > right)
                    dist3 = left;
                else
                    dist3 = right;
                max = dist1;
                if (dist2 > max)
                    max = dist2;
                if (dist3 > max)
                    max = dist3;
                if (Ans > max)
                    Ans = max;
            }
        }
    }
}

void printcase()
{
    printf("#%d %d\n", Case, Ans);
}

int main()
{
    freopen("river_input.txt", "r", stdin);
    freopen("test_output.txt", "w", stdout);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}