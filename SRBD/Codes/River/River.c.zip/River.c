#include <stdio.h>
int t, Case;
int p1, p2, p3, m1, m2, m3, ans;
int abss(int a, int b)
{
    return a > b ? a - b : b - a;
}
void input()
{
    scanf("%d%d%d%d%d%d", &p1, &m1, &p2, &m2, &p3, &m3);
}

void solve()
{

    int i, j, k;
    int left, right;
    int dist1, dist2, dist3, max;
    ans = 30;
    for (i = 1; i + m1 + m2 + m3 - 1 <= 30; i++)
    {
        left = abss(p1, i);
        right = abss(i + m1 - 1, p1);
        if (left > right)
            dist1 = left;
        else
            dist1 = right;

        for (j = i + m1; j + m2 + m3 - 1 <= 30; j++)
        {
            left = abss(p2, j);
            right = abss(p2, j + m2 - 1);
            if (left > right)
                dist2 = left;
            else
                dist2 = right;
            for (k = j + m2; k + m3 - 1 <= 30; k++)
            {
                left = abss(p3, k);
                right = abss(p3, k + m3 - 1);
                if (left > right)
                    dist3 = left;
                else
                    dist3 = right;

                max = dist1;
                if (dist2 > max)
                    max = dist2;
                if (dist3 > max)
                    max = dist3;

                if (ans > max)
                    ans = max;
            }
        }
    }
}
void print()
{
    printf("#%d %d\n", Case, ans);
}
int main()
{
    freopen("river_input.txt", "r", stdin);
    int i;
    scanf("%d", &t);
    for (Case = 1; Case <= t; Case++)
    {
        input();
        solve();
        print();
    }
}
