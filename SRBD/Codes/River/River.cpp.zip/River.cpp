#include <stdio.h>

int T;
int Case;
int p1, p2, p3;
int m1, m2, m3;
int Ans;

void read()
{
	scanf("%d %d", &p1, &m1);
	scanf("%d %d", &p2, &m2);
	scanf("%d %d", &p3, &m3);
}

int abs(int a, int b)
{
	if (a > b)
		return a - b;
	return b - a;
}
int Max(int a, int b)
{
	if (a > b)
		return a;
	return b;
}
int Min(int a, int b)
{
	if (a > b)
		return b;
	return a;
}

void solve()
{
	int i, j, k, left, right, dist1, dist2, dist3, max;
	Ans = 30;
	for (i = 1; i + m1 + m2 + m3 - 1 <= 30; i++)
	{
		left = abs(p1, i);
		right = abs(p1, (i + m1 - 1));
		dist1 = Max(left, right);
		for (j = i + m1; j + m2 + m3 - 1 <= 30; j++)
		{
			left = abs(p2, j);
			right = abs(p2, (j + m2 - 1));
			dist2 = Max(left, right);
			for (k = j + m2; k + m3 - 1 <= 30; k++)
			{
				left = abs(p3, k);
				right = abs(p3, (k + m3 - 1));
				dist3 = Max(left, right);

				max = Max(dist1, dist2);
				max = Max(max, dist3);
				Ans = Min(Ans, max);
			}
		}
	}
}

void print()
{
	printf("#%d %d\n", Case, Ans);
}

int main()
{
	freopen("river_input.txt", "r", stdin);
	scanf("%d", &T);
	for (Case = 1; Case <= T; Case++)
	{
		read();
		solve();
		print();
	}
}

// //RivergateORFisherman
// #include <stdio.h>

// int ans, p1, p2, p3, m1, m2, m3;

// void readcase()
// {
// 	scanf("%d %d", &p1, &m1);
// 	scanf("%d %d", &p2, &m2);
// 	scanf("%d %d", &p3, &m3);
// }

// void solvecase()
// {
// 	int i, j, k, left, right, dist1, dist2, dist3, max;
// 	ans = 30;
// 	for (i = 1; i + m1 + m2 + m3 - 1 <= 30; i++)
// 	{
// 		if (p1 > i)
// 		{
// 			left = p1 - i;
// 		}
// 		else
// 		{
// 			left = i - p1;
// 		}
// 		if (p1 > i + m1 - 1)
// 		{
// 			right = p1 - (i + m1 - 1);
// 		}
// 		else
// 		{
// 			right = (i + m1 - 1) - p1;
// 		}
// 		if (left > right)
// 		{
// 			dist1 = left;
// 		}
// 		else
// 		{
// 			dist1 = right;
// 		}
// 		for (j = i + m1; j + m2 + m3 - 1 <= 30; j++)
// 		{
// 			if (j > p2)
// 			{
// 				left = j - p2;
// 			}
// 			else
// 			{
// 				left = p2 - j;
// 			}
// 			if (p2 > j + m2 - 1)
// 			{
// 				right = p2 - (j + m2 - 1);
// 			}
// 			else
// 			{
// 				right = (j + m2 - 1) - p2;
// 			}
// 			if (left > right)
// 			{
// 				dist2 = left;
// 			}
// 			else
// 			{
// 				dist2 = right;
// 			}
// 			for (k = j + m2; k + m3 - 1 <= 30; k++)
// 			{
// 				if (k > p3)
// 				{
// 					left = k - p3;
// 				}
// 				else
// 				{
// 					left = p3 - k;
// 				}
// 				if (p3 > k + m3 - 1)
// 				{
// 					right = p3 - (k + m3 - 1);
// 				}
// 				else
// 				{
// 					right = (k + m3 - 1) - p3;
// 				}
// 				if (left > right)
// 				{
// 					dist3 = left;
// 				}
// 				else
// 				{
// 					dist3 = right;
// 				}
// 				max = dist1;
// 				if (dist2 > max)
// 				{
// 					max = dist2;
// 				}
// 				if (dist3 > max)
// 				{
// 					max = dist3;
// 				}
// 				if (max < ans)
// 				{
// 					ans = max;
// 				}
// 			}
// 		}
// 	}
// }

// int Case = 1;
// void printcase()
// {
// 	printf("#%d %d\n", Case++, ans);
// }

// int main()
// {
// 	int t;
// 	freopen("input.txt", "r", stdin);
// 	scanf("%d", &t);
// 	while (t--)
// 	{
// 		readcase();
// 		solvecase();
// 		printcase();
// 	}

// 	return 0;
// }