#include <stdio.h>
int t;
int n, m, time, ii;
float a[101][101];
float dp[101], dp1[101];

void input()
{
    scanf("%d%d%d", &n, &m, &time);
    int x, y;
    float z;
    for (int j = 0; j <= n; j++)
    {
        dp[j] = 0;
        dp1[j] = 0;
        for (int k = 0; k <= n; k++)
            a[j][k] = 0;
    }
    for (int j = 0; j < m; j++)
    {
        scanf("%d%d%f", &x, &y, &z);
        a[x][y] = z;
    }
}

void solve()
{
    dp[1] = dp1[1] = 1.0;
    float s = 0.0;
    for (int i = 1; i <= time / 10; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            s = 0.0;
            {
                if (dp[j] > 0)
                    for (int k = 1; k <= n; k++)
                    {

                        {
                            if (a[j][k] > 0)
                            {
                                dp1[k] = dp1[k] + a[j][k] * dp[j];
                                s += a[j][k] * dp[j];
                            }
                        }
                    }
                dp1[j] = dp1[j] - s;
            }
        }
        for (int j = 1; j <= n; j++)
            dp[j] = dp1[j];
        //      for(int j=1;j<=n;j++)
        //       printf("%f ",dp[j]);
        //       printf("\n");
    }
    float maxi = dp[1];
    int num = 1;
    for (int i = 2; i <= n; i++)
    {
        //printf("%d  %f\n",i,dp[i]);
        if (dp[i] > maxi)
        {
            maxi = dp[i];
            num = i;
        }
    }
    printf(" # %d  %f\n", num, maxi);
}
void print()
{
}
int main()
{
    freopen("probability_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &t);
    for (ii = 0; ii < t; ii++)
    {
        printf("%d ", ii + 1);
        input();
        solve();
        print();
    }
}
