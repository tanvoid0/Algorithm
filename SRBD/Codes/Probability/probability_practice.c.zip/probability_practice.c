#include <stdio.h>
#define sizen 102
int n, m, time, node;
int T, Case;
double Ans;

double pro[sizen][sizen];
double dp[sizen][sizen];

void readcase()
{
    int i, j, x, y;
    double p;
    scanf("%d %d %d", &n, &m, &time);
    for (i = 1; i <= n; i++)
        for (j = 1; j <= n; j++)
            pro[i][j] = 0.0;
    for (i = 0; i < m; i++)
    {
        scanf("%d %d %lf", &x, &y, &p);
        pro[x][y] = p;
    }
}

void solvecase()
{
    int i, j, k;
    Ans = 0;
    dp[0][1] = 1.0;
    for (j = 2; j <= n; j++)
        dp[0][j] = 0.0;
    for (i = 0; i < time / 10; i++)
    {
        for (j = 1; j <= n; j++)
            dp[i + 1][j] = 0.0;
        for (j = 1; j <= n; j++)
            if (dp[i][j] > 0)
                for (k = 1; k <= n; k++)
                    if (pro[j][k])
                        dp[i + 1][k] += dp[i][j] * pro[j][k];
    }
    for (j = 1; j <= n; j++)
        if (dp[i][j] > Ans)
        {
            Ans = dp[i][j];
            node = j;
        }
}

void printcase()
{
    printf("#%d %d %lf\n", Case, node, Ans);
}

int main()
{
    freopen("probability_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}