/*
    5.52m
    4.57m
*/
#include <stdio.h>
#define L 2.71828
#define MAXC 10000000000000
#define MINC 100000

int log(long long n)
{
    double d = (double)n;
    int value = 0;
    while (d >= L)
    {
        d /= L;
        value++;
    }
    return value;
}

long long a, b, c, x, n;
int T, Case;
void readcase()
{
    scanf("%lld %lld %lld %lld", &a, &b, &c, &x);
}

void solvecase()
{
    long long low, mid, high, result;
    low = n = 0;
    if (0 == c)
        high = MAXC;
    else
        high = MINC;
    while (low <= high)
    {
        mid = low + (high - low) / 2;
        result = a * mid + b * log(mid) + c * mid * mid * mid;
        if (x > result)
            low = mid + 1;
        else if (x < result)
            high = mid - 1;
        else
        {
            n = mid;
            break;
        }
    }
}

void printcase()
{
    printf("#%d %lld\n", Case, n);
}

int main()
{
    freopen("equation_input.txt", "r", stdin);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}