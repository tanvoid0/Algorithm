#include <stdio.h>
#include <math.h>
// X = A*N + B*log(N) + C*N*N*N
// Input A B C X
// Output N
// 1 <= A <= 100
// 1 <= B <= 100
// 0 <= C <= 100
// 0 <= X <= 10^15
// N must be integer
// 0 <= N <= 10^13
long long int t, a, b, c, x, ans, res;
long long logg(long long n)
{
    long long int value = log(n);
    return value;
}
long long int eqn(long long n)
{
    if (c == 0)
        return a * n + (b * logg(n));
    else
        return (a * n) + (b * logg(n)) + (c * n * n * n);
}

long long int mid;
long long int solve(long long int low, long long int high)
{
    if (low <= high)
    {
        //  printf("%lld  %lld\n",low,high);
        mid = (low + high) / 2;
        long long ress = eqn(mid);
        if (ress == x)
            return mid;
        if (ress < x)
            low = mid + 1;
        if (ress > x)
            high = mid - 1;
        return solve(low, high);
    }
    else
        return -1;
}
int main()
{
    int i;
    freopen("equation_input.txt", "r", stdin);
    scanf("%lld", &t);
    for (i = 0; i < t; i++)
    {
        long long int low, high;
        scanf("%lld%lld%lld%lld", &a, &b, &c, &x);
        if (c == 0)
        {
            low = 0;
            high = 10000000000000;
            ans = solve(0, 10000000000000);
        }
        else
        {
            low = 0;
            high = 100000;
            ans = solve(0, 100000);
        }
        printf("#%d %lld\n", i + 1, ans);
    }
}
