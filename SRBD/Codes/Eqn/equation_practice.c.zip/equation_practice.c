#include <stdio.h>
#define L 2.71828
#define MAXC 10000000000000
#define MINC 100000

int T, Case;
long long int A, B, C, X, N;

int log(long long n)
{
    double d = (double)n;
    int value = 0;
    while (d >= L)
    {
        d /= L;
        value++;
    }
    return value;
}

void readcase()
{
    scanf("%lld %lld %lld %lld", &A, &B, &C, &X);
}

void solvecase()
{
    long long low, mid, high, result;
    N = 0;
    low = 0;
    if (0 == C)
        high = MAXC;
    else
        high = MINC;
    while (low <= high)
    {
        mid = low + (high - low) / 2;
        result = A * mid + B * log(mid) + C * mid * mid * mid;
        if (X > result)
            low = mid + 1;
        else if (X < result)
            high = mid - 1;
        else
        {
            N = mid;
            break;
        }
    }
}

void printcase()
{
    printf("#%d %lld\n", Case, N);
}

int main()
{
    freopen("equation_input.txt", "r", stdin);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}