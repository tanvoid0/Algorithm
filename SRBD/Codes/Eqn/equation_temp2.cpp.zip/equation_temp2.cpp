#include <stdio.h>
#define L 2.71828
#define maxc 10000000000000
#define minc 100000

int T, Case;
int a, b, c, x, n;
int log(long long n)
{
	double d = (double)n;
	int value = 0;
	while (d >= L)
	{
		d /= L;
		value++;
	}
	return value;
}

void readcase()
{
	scanf("%lld %lld %lld %lld", &a, &b, &c, &x);
}

void printcase()
{
	printf("#%d %lld\n", Case, n);
}

void solvecase()
{
	long long int low, high, mid, result;
	n = 0;
	low = 0;
	if (0 == c)
		high = maxc;
	else
		high = minc;
	while (low <= high)
	{
		mid = (low + high) / 2;
		result = a * mid + b * log(mid) + c * mid * mid * mid;
		if (result == x)
		{
			n = mid;
			break;
		}
		else if (result > x)
			high = mid - 1;
		else if (result < x)
			low = mid + 1;
	}
}

int main()
{
	freopen("equation_input.txt", "r", stdin);
	scanf("%d", &T);
	for (Case = 1; Case <= T; Case++)
	{
		readcase();
		solvecase();
		printcase();
	}
	return 0;
}