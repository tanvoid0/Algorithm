﻿#include <stdio.h>
#define L 2.71828

int T, Case;
long long int A, B, C, X, N;

int log(long long n)
{
	double d = (double)n;
	int value = 0;
	while (d >= L)
	{
		d /= L;
		value++;
	}
	return value;
}

void read()
{
	scanf("%lld %lld %lld %lld", &A, &B, &C, &X);
}
void print()
{
	printf("#%d %lld\n", Case, N);
}

void solve()
{
	long long low, high, mid, result;
	N = 0;
	low = 0;
	if (0 == C)
		high = 10000000000000;
	else
		high = 100000;
	while (low <= high)
	{
		mid = low + (high - low) / 2;
		result = A * mid + B * log(mid) + C * mid * mid * mid;
		if (result < X)
			low = mid + 1;
		else if (result > X)
			high = mid - 1;
		else
		{
			N = mid;
			break;
		}
	}
}
int main()
{
	freopen("equation_input.txt", "r", stdin);
	scanf("%d", &T);
	for (Case = 1; Case <= T; Case++)
	{
		read();
		solve();
		print();
	}
}
