// Flip Bit
#include <stdio.h>

int T, Case, N, M, K;
int Bit[101][21];
int Zero[101];
int Value[101];
int Freq[101];
int Max;

void readcase(){
	int i, j;
	scanf("%d %d %d", &N, &M, &K);
	for (i = 0; i < N; i++)
		for (j = 0; j < M; j++)
			scanf("%d", &Bit[i][j]);
}

void solvecase(){
	int i, j;
	Max = 0;
	for (i = 0; i < N; i++){
		Zero[i] = Value[i] = 0;
		for (j = 0; j < M; j++){
			Value[i] = (Value[i] << 1) + Bit[i][j];
			if (0 == Bit[i][j])
				Zero[i]++;
		}
		for (j = i - 1; j >= 0; j--)if (Value[i] == Value[j]){
			Freq[i] = Freq[j] + 1;
			break;
		}
		if (j < 0)
			Freq[i] = 1;
		if (Zero[i] <= K && (K - Zero[i]) % 2 == 0){
			if (Freq[i]>Max)
				Max = Freq[i];
		}
	}
}

void printcase(){
	printf("#%d %d\n", Case, Max);
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d", &T);
	for (Case = 1; Case <= T; Case++){
		readcase();
		solvecase();
		printcase();
	}
	return 0;
}