#include<stdio.h>
int t;
int n,m,k;
int mat[100][100];
int num[100];
int zero[100];
int cnt;
void input()
{
	scanf("%d%d%d",&n,&m,&k);
	for(int i=0;i<100;i++) {
		num[i]=0;
    	zero[i]=0;
    }
	for(int i=0;i<n;i++){
	    for(int j=0;j<m;j++){
        	scanf("%d",&mat[i][j]);
			if(mat[i][j]==1){
    			num[i]+=num[i]*2+1;
			}
			else{
				zero[i]++;
				num[i]+=num[i]*2;
			}
		}
	}
}

void solve(){
	int cnt=0;
	int ans=0;
	for(int i=0;i<n;i++){
        if(zero[i]!=-1&&zero[i]<=k&&((k-zero[i])%2)==0){
        	cnt=1;
            for(int j=i+1;j<n;j++){
                if(num[i]==num[j])
                {
                    cnt++;
                    zero[j]=-1;
                }
            }
            if(cnt>ans)
                ans=cnt;

        }
    }
    printf("%d\n",ans);
}
void print()
{

}
int main(){
	freopen("out.txt","w",stdout);
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
        input();
        solve();
        print();
    }
    return 0;
}