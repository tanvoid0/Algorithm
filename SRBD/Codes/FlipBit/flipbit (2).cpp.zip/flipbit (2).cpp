//flip bit
#include<stdio.h>
int t, Case, n, m, k;
int bit[101][21];
int zero[101];
int value[101];
int freq[101];
int max;
void readcase()
{
	int i, j;
	scanf("%d%d%d", &n, &m, &k);
	for (i = 0; i < n; i++)
		for (j = 0; j < m; j++)
			scanf("%d", &bit[i][j]);
}
void solvecase()
{
	int i, j;
	max = 0;
	for (i = 0; i < n; i++)
	{
		zero[i] = value[i] = 0;
		for (j = 0; j < m; j++)
		{
			value[i] = (value[i] << 1) + bit[i][j];
			if (0 == bit[i][j])
				zero[i]++;
		}
		for (j = i - 1; j >= 0; j--)
		{
			if (value[i] == value[j])
			{
				freq[i] = freq[j] + 1;
				break;
			}
		}
		if (j < 0)
			freq[i] = 1;
		if (zero[i] <= k && (k - zero[i]) % 2 == 0)
		{
			if (freq[i] > max)
			{
				max = freq[i];
			}
		}
	}
}
void printcase()
{
	printf("#%d %d\n", Case, max);
}
int main()
{
	scanf("%d", &t);
	for (Case = 1; Case <= t; Case++)
	{
		readcase();
		solvecase();
		printcase();
	}
	return 0;
}
