//TSP problem
#include <stdio.h>
#define MAX 101
int x[MAX], y[MAX], A[MAX], visited[MAX];
int N, T, Case, min;
void readcase()
{
	int i;

	scanf("%d", &N);
	scanf("%d %d", &x[0], &y[0]);
	scanf("%d %d", &x[N + 1], &y[N + 1]);

	for (i = 1; i <= N; i++)
	{
		scanf("%d %d", &x[i], &y[i]);
	}
}
int diff(int i, int j)
{
	int dist;
	/*if (x[i] > x[j]){
		dist = x[i] - x[j];
	}
	else{
		dist = x[j] - x[i];
	}
	if (y[i] > y[j]){
		dist += y[i] - y[j];
	}
	else{
		dist += y[j] - y[i];
	}*/
	dist = x[i] > x[j] ? x[i] - x[j] : x[j] - x[i];
	dist += y[i] > y[j] ? y[i] - y[j] : y[j] - y[i];

	return dist;
}
void solve(int i, int dist)
{
	int j;
	if (dist >= min)
		return;
	if (i == N + 1)
	{
		dist += diff(i, A[i - 1]);
		if (dist < min)
		{
			min = dist;
			return;
		}
	}
	for (j = 1; j <= N; j++)
	{
		if (visited[j] == 0)
		{
			visited[j] = 1;
			A[i] = j;
			solve(i + 1, dist + diff(A[i], A[i - 1]));
			visited[j] = 0;
		}
	}
}
void solvecase()
{
	int i;

	min = MAX * MAX;
	for (i = 0; i < MAX; i++)
	{
		visited[i] = 0;
	}
	A[0] = 0;
	solve(1, 0);
}
void printcase()
{
	printf("#%d %d\n", Case++, min);
}

int main()
{
	freopen("tsp_input.txt", "r", stdin);
	scanf("%d", &T);
	while (T--)
	{
		readcase();
		solvecase();
		printcase();
	}

	return 0;
}
///input
/*
3
5
0 0 100 100 70 40 30 10 10 5 90 70 50 20
6
88 81 85 80 19 22 31 15 27 29 30 10 20 26 5 14
10
39 9 97 61 35 93 62 64 96 39 36 36 9 59 59 96 61 7 64 43 43 58 1 36
*/

///output
/*
#1 200
#2 304
#3 366
*/