#include <stdio.h>
#define MAX 101
#define inf (MAX*MAX)
int x[MAX], y[MAX], TSP[MAX], vis[MAX];
int N, T, Case, min;

int diff(int i, int j)
{
    int dist = x[i] > x[j] ? x[i] - x[j] : x[j] - x[i];
    return dist += y[i] > y[j] ? y[i] - y[j] : y[j] - y[i];
}

void readcase()
{
    int i;
    scanf("%d", &N);
    scanf("%d %d %d %d", &x[0], &y[0], &x[N + 1], &y[N + 1]);
    vis[0] = 0;
    for (i = 1; i <= N; i++)
    {
        scanf("%d %d", &x[i], &y[i]);
        vis[i] = 0;
    }
}

void solve(int i, int dist)
{
    int j;
    if (min <= dist)
        return;
    if (i == N + 1)
    {
        dist += diff(i, TSP[i - 1]);
        if (min > dist)
        {
            min = dist;
            return;
        }
    }

    for (j = 1; j <= N; j++)
    {
        if (!vis[j])
        {
            vis[j] = 1;
            TSP[i] = j;
            solve(i + 1, dist + diff(TSP[i], TSP[i - 1]));
            vis[j] = 0;
        }
    }
}

void solvecase()
{
    min = inf;
    TSP[0] = 0;
    solve(1, 0);
}

void printcase()
{
    printf("#%d %d\n", Case, min);
}

int main()
{
    freopen("tsp_input.txt", "r", stdin);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}