#include <stdio.h>
#define MAX 101
int x[MAX], y[MAX], A[MAX], vis[MAX];
int N, T, Case, min;

void readcase()
{
    int i;
    scanf("%d", &N);
    scanf("%d %d", &x[0], &y[0]);
    scanf("%d %d", &x[N + 1], &y[N + 1]);
    vis[0] = 0;
    for (i = 1; i <= N; i++)
    {
        scanf("%d %d", &x[i], &y[i]);
        vis[i] = 0;
    }
}

int diff(int i, int j)
{
    int dist;
    dist = x[i] > x[j] ? x[i] - x[j] : x[j] - x[i];
    dist += y[i] > y[j] ? y[i] - y[j] : y[j] - y[i];
    return dist;
}

void solve(int i, int dist)
{
    int j;
    if (dist >= min)
        return;
    if (i == N + 1)
    {
        dist += diff(i, A[i - 1]);
        if (dist < min)
        {
            min = dist;
            return;
        }
    }
    for (j = 1; j <= N; j++)
        if (0 == vis[j])
        {
            vis[j] = 1;
            A[i] = j;
            solve(i + 1, dist + diff(A[i], A[i - 1]));
            vis[j] = 0;
        }
}

void solvecase()
{
    int i;
    min = MAX * MAX;
    A[0] = 0;
    solve(1, 0);
}
void printcase()
{
    printf("#%d %d\n", Case, min);
}

int main()
{
    freopen("tsp_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}
