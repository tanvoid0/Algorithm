#include<stdio.h>//cycle
int N;
int edge;
int grid[100][100];
int color[100];

void init_grid()
{
	for (int i = 0; i < 100; i++)
	{
		color[i] = 0;
		for (int j = 0; j < 100; j++)
			grid[i][j] = 0;
	}
}
void input()
{
	int x, y;
	scanf("%d%d", &N, &edge);
	for (int i = 0; i < edge; i++)
	{
		scanf("%d%d", &x, &y);
		grid[x][y] = 1;
		grid[y][x] = 1;
	}
}
int solve(int x,int c)
{
	if (color[x] != 0 && color[x] != c)
		return color[x];
	color[x] = c;
	int r;
	for (int j = 0; j < N; j++)
	{
		if (grid[x][j])
		{
			grid[x][j] = 0;
			grid[j][x] = 0;
			r = solve(j, c + 1);
			if (r != -1)
				return r;
		}
	}
	color[x] = 0;
	return -1;
}
void cycle()
{
	int ans;
	ans = solve(0, 1);
	if (ans!=-1)
	{
		for (int i = 0; i < N; i++)
		{
			if (color[i] >= ans)
				printf("%d ", i);

		}
		printf("\n");
	}
}
int main()
{
	int test;
	scanf("%d", &test);
	while (test--)
	{
		input();
		cycle();
	}
}