#include <stdio.h>
#define size 101
#define inf (size * size)

int T, Case, Ans;
int N, X, Y;
int grid[size][size];
int dp[size][size];

void readcase()
{
    int i, j;
    scanf("%d", &N);
    for (i = 0; i < N; i++)
        for (j = 0; j < N; j++)
        {
            scanf("%d", &grid[i][j]);
            dp[i][j] = inf;
            if (3 == grid[i][j])
            {
                X = i;
                Y = j;
            }
        }
}

void solve(int x, int y, int maxzero, int curzero)
{
    if (0 == grid[x][y])
        curzero++;
    else
        curzero = 0;
    if (curzero > maxzero)
        maxzero = curzero;
    if (maxzero < dp[x][y])
        dp[x][y] = maxzero;
    else
        return;
    if (x - 1 >= 0)
        solve(x - 1, y, maxzero, curzero);
    if (x + 1 < N)
        solve(x + 1, y, maxzero, curzero);
    if (y - 1 >= 0 && grid[x][y - 1])
        solve(x, y - 1, maxzero, curzero);
    if (y + 1 < N && grid[x][y + 1])
        solve(x, y + 1, maxzero, curzero);
}

void solvecase()
{
    solve(N - 1, 0, 0, 0);
    if (inf == dp[X][Y])
        dp[X][Y] = -1;
}

void printcase()
{
    printf("#%d %d\n", Case, dp[X][Y]);
}

int main()
{
    freopen("rock_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}