
1 lok er 1 km jete mm:ss time lage and ei time e se E energy khoros kore. take 5ta time set dea thakbe, tar energy level and take koto km jete hobe seta dea thakbe. akon ber korte hobe j se minimum koto time e D km jete pare.

Cons:

H, D  H is his energy level, D is koto km jete hobe. H > 10 && H <= 6000, D <= 40


I/O
1
130 30 // 130 energy, 30Km distance 
5 30 5 // 5 min, 30 seconds, cost 5 energe for 1 KM.
5 2 4
5 20 7
4 7 10
4 30 9

#1 149 56 // #1 case number, 149 min, 56 seconds

#include<stdio.h>
 
int main()
{
    int cs;
    scanf("%d", &cs);
    for(int ii =1; ii <= cs; ii++)
    {
        int h, d, e[10], ttt, tt, t[10];
        scanf("%d %d", &h, &d);
 
        for(int i =0; i<5; i++)
        {
            scanf("%d %d %d", &ttt, &tt, &e[i]);
            t[i] = ttt* 60 + tt;
        }
 
        int mn = 99999999;
        for(int i = 0; i <= d; i++)
        {
            for(int j =0; j <= d - i; j++)
            {
                for(int k = 0; k <= d - i - j; k++)
                {
                    for(int l = 0; l <= d - i - j - k; l++)
                    {
                        for(int m = 0; m <= d - i - j - k - l; m++)
                        {
                            if(i + j + k + l + m == d)
                            {
                                if(e[0]*i + e[1]*j + e[2]*k + e[3]*l + e[4]*m <= h)
                                {
                                    if(t[0]*i + t[1]*j + t[2]*k + t[3]*l + t[4]*m < mn)
                                        mn = t[0]*i + t[1]*j + t[2]*k + t[3]*l + t[4]*m;
                                }
                            }
                        }
                    }
                }
            }
        }
        printf("#%d %d %d\\n", ii, mn/60, mn%60);
    }
}
