#include <stdio.h>
#define MAX 202
#define inf (10001 * 10001)
int T, Case, Ans;
int a[MAX][MAX];
int x[MAX], y[MAX];
int dp[MAX][MAX][5];
int n, m, c;
int max, min;

void readcase()
{
    int i, j, k;
    scanf("%d %d %d", &n, &m, &c);
    for (i = 0; i < n; i++)
        for (j = 0; j < m; j++)
        {
            scanf("%d", &a[i][j]);
            for (k = 0; k < c; k++)
                dp[i][j][k] = inf;
        }
    for (i = 0; i < c; i++)
        scanf("%d %d", &x[i], &y[i]);
}

void solve(int i, int j, int k, int cost)
{
    if (cost < dp[i][j][k])
        dp[i][j][k] = cost;
    else
        return;
    if (a[i][j])
    {
        if (i - 1 >= 0)
            solve(i - 1, j, k, cost + 1);
        if (i + 1 < n)
            solve(i + 1, j, k, cost + 1);
        if (j - 1 >= 0)
            solve(i, j - 1, k, cost + 1);
        if (j + 1 < m)
            solve(i, j + 1, k, cost + 1);
    }
}

void solvecase()
{
    int i, j, k;

    for (k = 0; k < c; k++)
        solve(x[k], y[k], k, 0);
    Ans = inf;
    for (i = 0; i < n; i++)
        for (j = 0; j < m; j++)
            if (!a[i][j])
            {
                max = dp[i][j][0];
                for (k = 0; k < c; k++)
                    if (max < dp[i][j][k])
                        max = dp[i][j][k];
                if (max < Ans)
                    Ans = max;
            }
}

void printcase()
{
    printf("#%d %d\n", Case, Ans == inf ? -1 : Ans);
}

int main()
{
    freopen("research_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &T);
    for (Case = 1; Case <= T; Case++)
    {
        readcase();
        solvecase();
        printcase();
    }
    return 0;
}