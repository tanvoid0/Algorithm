#include <stdio.h>
int t;
int a[200][200];
int x[200], y[200];
int dp[200][200][5];
int n, m, c;
int ans, max, min;
void input()
{
    scanf("%d%d%d", &n, &m, &c);
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            scanf("%d", &a[i][j]);
            for (int k = 0; k < c; k++)
                dp[i][j][k] = 100000000;
        }
    }
    for (int i = 0; i < c; i++)
        scanf("%d%d", &x[i], &y[i]);
}
void print()
{
    if (ans == 100000000)
        printf("-1\n");
    else
        printf("%d\n", ans);
}
void solve(int i, int j, int k, int cost)
{
    if (dp[i][j][k] > cost)
    {
        dp[i][j][k] = cost;
    }
    else
        return;
    //printf("%d %d %d\n",i,j,k);
    if (a[i][j])
    {
        if (i + 1 < n)
            solve(i + 1, j, k, cost + 1);

        if (i - 1 >= 0)
            solve(i - 1, j, k, cost + 1);

        if (j + 1 < m)
            solve(i, j + 1, k, cost + 1);

        if (j - 1 >= 0)
            solve(i, j - 1, k, cost + 1);
    }
}
void solvecase()
{

    for (int k = 0; k < c; k++)
    {
        solve(x[k], y[k], k, 0);
    }

    ans = 100000000;
    //int x, y;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (a[i][j] == 0)
            {
                max = dp[i][j][0];

                for (int k = 0; k < c; k++)
                {
                    // printf("distance= %d from %d, %d\n",dp[i][j][k],i,j);
                    if (dp[i][j][k] > max)
                        max = dp[i][j][k];
                }
                if (ans > max)
                {
                    ans = max;
                    // printf("%d %d\n",i,j);
                }
            }
        }
    }
}
int main()
{
    freopen("research_input.txt", "r", stdin);
    freopen("test.txt", "w", stdout);
    scanf("%d", &t);
    for (int i = 0; i < t; i++)
    {
        printf("#%d ", i + 1);
        input();
        solvecase();
        print();
    }
}
